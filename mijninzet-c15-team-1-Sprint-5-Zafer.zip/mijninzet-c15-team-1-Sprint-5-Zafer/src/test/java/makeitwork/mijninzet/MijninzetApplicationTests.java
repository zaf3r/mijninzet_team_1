package makeitwork.mijninzet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.BeforeEach;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MijninzetApplicationTests {

	@Test
	public void contextLoads() {
	}


//	@Test
//	public void testEquals(){
//		TaskInlezen.tasks();
//	}
}
