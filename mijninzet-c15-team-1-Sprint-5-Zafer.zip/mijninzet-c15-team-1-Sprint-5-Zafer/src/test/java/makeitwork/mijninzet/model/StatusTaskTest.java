//package makeitwork.mijninzet.model;
//
//import org.junit.Test;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//class StatusTaskTest {
//
//    @Test
//    public void StatusTaskTest (){
//
//        StatusTask statusTask = StatusTask.APPROVED;
//        System.out.println("Uw sollicitatie is " + statusTask);
//
//
//    }
//
//
//}