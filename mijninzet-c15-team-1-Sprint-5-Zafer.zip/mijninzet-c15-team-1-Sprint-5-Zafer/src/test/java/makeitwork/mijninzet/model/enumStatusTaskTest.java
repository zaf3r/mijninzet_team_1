//package makeitwork.mijninzet.model;
//
//import org.junit.Test;
//
//class enumStatusTaskTest {
//
//    @Test
//    public void enumStatusTask(){
//        enumStatusTask.Status status = enumStatusTask.Status.APPROVED;
//        System.out.println("Uw sollicitatie is " + status);
//        assertE
//    }
//
//
//
//}