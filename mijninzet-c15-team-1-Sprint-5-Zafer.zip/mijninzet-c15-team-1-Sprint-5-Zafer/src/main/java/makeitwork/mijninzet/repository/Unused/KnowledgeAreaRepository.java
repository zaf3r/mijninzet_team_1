package makeitwork.mijninzet.repository.Unused;

/*
public interface KnowledgeAreaRepository extends JpaRepository<KnowledgeArea, Integer> {
    List<KnowledgeArea> findAllByOrderByKnowledgeAreaIdAsc();
    KnowledgeArea findByKnowledgeAreaId(int id);
}
*/

