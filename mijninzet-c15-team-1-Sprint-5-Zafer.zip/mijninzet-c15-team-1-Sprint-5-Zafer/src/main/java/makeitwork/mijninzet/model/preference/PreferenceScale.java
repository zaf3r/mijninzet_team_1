package makeitwork.mijninzet.model.preference;

public class PreferenceScale {

    private int scale;

    public PreferenceScale() {
    }

    public PreferenceScale(int scale) {
        this.scale = scale;
    }

    public int getScale() {
        return scale;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }
}
