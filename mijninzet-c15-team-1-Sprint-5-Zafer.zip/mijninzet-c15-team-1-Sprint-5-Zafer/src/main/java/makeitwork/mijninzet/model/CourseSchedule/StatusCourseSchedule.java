package makeitwork.mijninzet.model.CourseSchedule;

public enum StatusCourseSchedule {
    INPLANNING,
    DEFINITIEF
}
