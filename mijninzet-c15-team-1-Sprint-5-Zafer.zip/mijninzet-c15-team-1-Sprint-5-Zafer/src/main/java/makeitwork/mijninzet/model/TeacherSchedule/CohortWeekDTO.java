package makeitwork.mijninzet.model.TeacherSchedule;

public class CohortWeekDTO {

    private String cohort;
    private long weekNumber;

    private String mondayMorningTeacher;
    private String mondayAfternoonTeacher;
    private String mondayEveningTeacher;

    private String tuesdayMorningTeacher;
    private String tuesdayAfternoonTeacher;
    private String tuesdayEveningTeacher;

    private String wednesdayMorningTeacher;
    private String wednesdayAfternoonTeacher;
    private String wednesdayEveningTeacher;

    private String thursdayMorningTeacher;
    private String thursdayAfternoonTeacher;
    private String thursdayEveningTeacher;

    private String fridayMorningTeacher;
    private String fridayAfternoonTeacher;
    private String fridayEveningTeacher;

    public String getCohort() {
        return cohort;
    }

    public void setCohort(String cohort) {
        this.cohort = cohort;
    }

    public long getWeekNumber() {
        return weekNumber;
    }

    public void setWeekNumber(long weekNumber) {
        this.weekNumber = weekNumber;
    }

    public String getMondayMorningTeacher() {
        return mondayMorningTeacher;
    }

    public void setMondayMorningTeacher(String mondayMorningTeacher) {
        this.mondayMorningTeacher = mondayMorningTeacher;
    }

    public String getMondayAfternoonTeacher() {
        return mondayAfternoonTeacher;
    }

    public void setMondayAfternoonTeacher(String mondayAfternoonTeacher) {
        this.mondayAfternoonTeacher = mondayAfternoonTeacher;
    }

    public String getMondayEveningTeacher() {
        return mondayEveningTeacher;
    }

    public void setMondayEveningTeacher(String mondayEveningTeacher) {
        this.mondayEveningTeacher = mondayEveningTeacher;
    }

    public String getTuesdayMorningTeacher() {
        return tuesdayMorningTeacher;
    }

    public void setTuesdayMorningTeacher(String tuesdayMorningTeacher) {
        this.tuesdayMorningTeacher = tuesdayMorningTeacher;
    }

    public String getTuesdayAfternoonTeacher() {
        return tuesdayAfternoonTeacher;
    }

    public void setTuesdayAfternoonTeacher(String tuesdayAfternoonTeacher) {
        this.tuesdayAfternoonTeacher = tuesdayAfternoonTeacher;
    }

    public String getTuesdayEveningTeacher() {
        return tuesdayEveningTeacher;
    }

    public void setTuesdayEveningTeacher(String tuesdayEveningTeacher) {
        this.tuesdayEveningTeacher = tuesdayEveningTeacher;
    }

    public String getWednesdayMorningTeacher() {
        return wednesdayMorningTeacher;
    }

    public void setWednesdayMorningTeacher(String wednesdayMorningTeacher) {
        this.wednesdayMorningTeacher = wednesdayMorningTeacher;
    }

    public String getWednesdayAfternoonTeacher() {
        return wednesdayAfternoonTeacher;
    }

    public void setWednesdayAfternoonTeacher(String wednesdayAfternoonTeacher) {
        this.wednesdayAfternoonTeacher = wednesdayAfternoonTeacher;
    }

    public String getWednesdayEveningTeacher() {
        return wednesdayEveningTeacher;
    }

    public void setWednesdayEveningTeacher(String wednesdayEveningTeacher) {
        this.wednesdayEveningTeacher = wednesdayEveningTeacher;
    }

    public String getThursdayMorningTeacher() {
        return thursdayMorningTeacher;
    }

    public void setThursdayMorningTeacher(String thursdayMorningTeacher) {
        this.thursdayMorningTeacher = thursdayMorningTeacher;
    }

    public String getThursdayAfternoonTeacher() {
        return thursdayAfternoonTeacher;
    }

    public void setThursdayAfternoonTeacher(String thursdayAfternoonTeacher) {
        this.thursdayAfternoonTeacher = thursdayAfternoonTeacher;
    }

    public String getThursdayEveningTeacher() {
        return thursdayEveningTeacher;
    }

    public void setThursdayEveningTeacher(String thursdayEveningTeacher) {
        this.thursdayEveningTeacher = thursdayEveningTeacher;
    }

    public String getFridayMorningTeacher() {
        return fridayMorningTeacher;
    }

    public void setFridayMorningTeacher(String fridayMorningTeacher) {
        this.fridayMorningTeacher = fridayMorningTeacher;
    }

    public String getFridayAfternoonTeacher() {
        return fridayAfternoonTeacher;
    }

    public void setFridayAfternoonTeacher(String fridayAfternoonTeacher) {
        this.fridayAfternoonTeacher = fridayAfternoonTeacher;
    }

    public String getFridayEveningTeacher() {
        return fridayEveningTeacher;
    }

    public void setFridayEveningTeacher(String fridayEveningTeacher) {
        this.fridayEveningTeacher = fridayEveningTeacher;
    }
}
