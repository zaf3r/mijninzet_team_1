package makeitwork.mijninzet.model.Availability.GlobalAvailability;

public class AvailabilityForm {

    private Availability availabilityMonday;
    private Availability availabilityTuesday;
    private Availability availabilityWednesday;
    private Availability availabilityThursday;
    private Availability availabilityFriday;

    public Availability getAvailabilityMonday() {
        return availabilityMonday;
    }

    public void setAvailabilityMonday(Availability availabilityMonday) {
        this.availabilityMonday = availabilityMonday;
    }

    public Availability getAvailabilityTuesday() {
        return availabilityTuesday;
    }

    public void setAvailabilityTuesday(Availability availabilityTuesday) {
        this.availabilityTuesday = availabilityTuesday;
    }

    public Availability getAvailabilityWednesday() {
        return availabilityWednesday;
    }

    public void setAvailabilityWednesday(Availability availabilityWednesday) {
        this.availabilityWednesday = availabilityWednesday;
    }

    public Availability getAvailabilityThursday() {
        return availabilityThursday;
    }

    public void setAvailabilityThursday(Availability availabilityThursday) {
        this.availabilityThursday = availabilityThursday;
    }

    public Availability getAvailabilityFriday() {
        return availabilityFriday;
    }

    public void setAvailabilityFriday(Availability availabilityFriday) {
        this.availabilityFriday = availabilityFriday;
    }

    @Override
    public String toString() {
        return "AvailabilityForm{" +
                "availabilityMonday=" + availabilityMonday +
                ", availabilityTuesday=" + availabilityTuesday +
                ", availabilityWednesday=" + availabilityWednesday +
                ", availabilityThursday=" + availabilityThursday +
                ", availabilityFriday=" + availabilityFriday +
                '}';
    }
}


