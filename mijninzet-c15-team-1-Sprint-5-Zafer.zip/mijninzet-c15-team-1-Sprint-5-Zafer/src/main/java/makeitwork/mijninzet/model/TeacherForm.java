package makeitwork.mijninzet.model;

public class TeacherForm {

    public TeacherForm() {
    }

}
