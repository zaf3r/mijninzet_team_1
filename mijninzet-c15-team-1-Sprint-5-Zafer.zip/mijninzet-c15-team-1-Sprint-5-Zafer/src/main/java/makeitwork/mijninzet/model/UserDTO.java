package makeitwork.mijninzet.model;

public class UserDTO {
}
