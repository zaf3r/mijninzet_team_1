package makeitwork.mijninzet.model.Availability.Incident;

public class IncidentForm {

    private Incident incidentMonday;
    private Incident incidentTuesday;
    private Incident incidentWednesday;
    private Incident incidentThursday;
    private Incident incidentFriday;

    public Incident getIncidentMonday() {
        return incidentMonday;
    }

    public void setIncidentMonday(Incident incidentMonday) {
        this.incidentMonday = incidentMonday;
    }

    public Incident getIncidentTuesday() {
        return incidentTuesday;
    }

    public void setIncidentTuesday(Incident incidentTuesday) {
        this.incidentTuesday = incidentTuesday;
    }

    public Incident getIncidentWednesday() {
        return incidentWednesday;
    }

    public void setIncidentWednesday(Incident incidentWednesday) {
        this.incidentWednesday = incidentWednesday;
    }

    public Incident getIncidentThursday() {
        return incidentThursday;
    }

    public void setIncidentThursday(Incident incidentThursday) {
        this.incidentThursday = incidentThursday;
    }

    public Incident getIncidentFriday() {
        return incidentFriday;
    }

    public void setIncidentFriday(Incident incidentFriday) {
        this.incidentFriday = incidentFriday;
    }

    @Override
    public String toString() {
        return "IncidentForm{" +
                "incidentMonday=" + incidentMonday +
                ", incidentTuesday=" + incidentTuesday +
                ", incidentWednesday=" + incidentWednesday +
                ", incidentThursday=" + incidentThursday +
                ", incidentFriday=" + incidentFriday +
                '}';
    }
}
