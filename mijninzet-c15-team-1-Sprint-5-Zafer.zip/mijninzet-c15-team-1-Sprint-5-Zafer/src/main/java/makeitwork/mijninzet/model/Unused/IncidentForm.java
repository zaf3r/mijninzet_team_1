package makeitwork.mijninzet.model.Unused;

import java.util.List;

public class IncidentForm {

    private List<IncidentForm> incidents;

    public List<IncidentForm> getIncidents() { return incidents; }
    public void setIncidents(List<IncidentForm> incidents) { this.incidents = incidents; }
}
