package makeitwork.mijninzet.model;

import makeitwork.mijninzet.model.preference.Subject;

public class SubjectResponse {

    private Subject subject;

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }
}
