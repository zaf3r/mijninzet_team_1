package makeitwork.mijninzet.model;


import lombok.Data;


public class InfoBy {

    private String name;
    private String email;
    private String telefoon;
}
