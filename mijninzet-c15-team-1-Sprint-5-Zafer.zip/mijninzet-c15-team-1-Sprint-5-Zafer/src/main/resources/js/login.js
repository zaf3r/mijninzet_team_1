//
// $("#formButton").click(function(){
//     $("form-group").toggle();
// });


$(document).ready(function(){
    $('#show').click(function() {
        $('.menu').toggle("slide");
    });
});
