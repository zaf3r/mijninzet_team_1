// select date
$( function() {
    $( "#from" ).datepicker({
        changeMonth: true,
        changeYear: true
    });

    $( "#to" ).datepicker({
        changeMonth: true,
        changeYear: true
    });
} );

