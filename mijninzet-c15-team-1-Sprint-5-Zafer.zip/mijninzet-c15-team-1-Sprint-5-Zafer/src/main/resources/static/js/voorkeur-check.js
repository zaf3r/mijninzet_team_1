var btn = document.querySelector("#submitButton");


btn.addEventListener("click", function () {
    alert("Voorkeuren zijn opgeslagen")
});